#include "Timer.h"



Timer::~Timer(void)
{
}
